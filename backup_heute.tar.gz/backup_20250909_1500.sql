--
-- PostgreSQL database dump
--

\restrict 7x5ezjXa3ucLesaf3Ndbr2CE3MTPrNU8EtM9CLYUaRyWhwp8vQXwmiI3PbwqrHP

-- Dumped from database version 15.14 (Ubuntu 15.14-1.pgdg24.04+1)
-- Dumped by pg_dump version 15.14 (Ubuntu 15.14-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: billingtype; Type: TYPE; Schema: public; Owner: seda24_user
--

CREATE TYPE public.billingtype AS ENUM (
    'PAUSCHALE',
    'STUNDENBASIS',
    'MISCHFORM'
);


ALTER TYPE public.billingtype OWNER TO seda24_user;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: seda24_user
--

CREATE TYPE public.userrole AS ENUM (
    'ADMIN',
    'OBJEKTLEITER',
    'MITARBEITER'
);


ALTER TYPE public.userrole OWNER TO seda24_user;

--
-- Name: copy_week_schedules(date, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.copy_week_schedules(source_week_start date, target_week_start date) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    copied_count INTEGER := 0;
    schedule_record RECORD;
BEGIN
    FOR schedule_record IN 
        SELECT * FROM schedules 
        WHERE status = 'normal'
    LOOP
        -- Prüfe ob bereits existiert
        IF NOT EXISTS (
            SELECT 1 FROM schedules 
            WHERE employee_id = schedule_record.employee_id
            AND object_id = schedule_record.object_id
            AND weekday = schedule_record.weekday
        ) THEN
            INSERT INTO schedules (
                employee_id, object_id, weekday, 
                start_time, end_time, planned_hours, status
            ) VALUES (
                schedule_record.employee_id,
                schedule_record.object_id,
                schedule_record.weekday,
                schedule_record.start_time,
                schedule_record.end_time,
                schedule_record.planned_hours,
                'normal'
            );
            copied_count := copied_count + 1;
        END IF;
    END LOOP;
    
    RETURN copied_count;
END;
$$;


ALTER FUNCTION public.copy_week_schedules(source_week_start date, target_week_start date) OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: seda24_user
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO seda24_user;

--
-- Name: break_entries; Type: TABLE; Schema: public; Owner: seda24_user
--

CREATE TABLE public.break_entries (
    id integer NOT NULL,
    time_entry_id integer,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone,
    is_paid boolean,
    break_type character varying
);


ALTER TABLE public.break_entries OWNER TO seda24_user;

--
-- Name: break_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: seda24_user
--

CREATE SEQUENCE public.break_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.break_entries_id_seq OWNER TO seda24_user;

--
-- Name: break_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seda24_user
--

ALTER SEQUENCE public.break_entries_id_seq OWNED BY public.break_entries.id;


--
-- Name: correction_requests; Type: TABLE; Schema: public; Owner: seda24_user
--

CREATE TABLE public.correction_requests (
    id integer NOT NULL,
    employee_id integer,
    time_entry_id integer,
    correction_type character varying,
    old_value character varying,
    new_value character varying,
    reason text,
    status character varying,
    admin_response text,
    processed_by integer,
    processed_at timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.correction_requests OWNER TO seda24_user;

--
-- Name: correction_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: seda24_user
--

CREATE SEQUENCE public.correction_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.correction_requests_id_seq OWNER TO seda24_user;

--
-- Name: correction_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seda24_user
--

ALTER SEQUENCE public.correction_requests_id_seq OWNED BY public.correction_requests.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: seda24_user
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name character varying,
    address character varying,
    billing_type character varying(50),
    monthly_rate double precision,
    created_at timestamp without time zone,
    is_active boolean
);


ALTER TABLE public.customers OWNER TO seda24_user;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: seda24_user
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    user_id integer,
    personal_nr character varying,
    first_name character varying,
    last_name character varying,
    hourly_rate double precision,
    kuerzel character varying,
    monthly_amount double precision DEFAULT 556.00,
    address text,
    gps_required boolean DEFAULT true,
    auto_stamp boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    hourly_rate_standard double precision DEFAULT 15.00,
    hourly_rate_window double precision DEFAULT 20.00,
    hourly_rate_basic double precision DEFAULT 20.00,
    tracking_mode character varying(1) DEFAULT 'C'::character varying,
    start_hours numeric(10,2) DEFAULT 0,
    employment_type character varying(20) DEFAULT 'minijob'::character varying,
    max_monthly_amount numeric(7,2) DEFAULT 556.00,
    total_hours_since_start double precision DEFAULT 0.0
);


ALTER TABLE public.employees OWNER TO seda24_user;

--
-- Name: objects; Type: TABLE; Schema: public; Owner: seda24_user
--

CREATE TABLE public.objects (
    id integer NOT NULL,
    customer_id integer,
    name character varying,
    address character varying,
    gps_lat double precision,
    gps_lng double precision,
    radius_meters integer,
    created_at timestamp without time zone,
    is_active boolean,
    radius_m integer DEFAULT 100,
    cleaning_type character varying(50) DEFAULT 'Grundreinigung'::character varying,
    monthly_amount numeric(8,2),
    cleaning_interval character varying(20) DEFAULT 'täglich'::character varying,
    cleaning_days character varying(50) DEFAULT 'Mo,Di,Mi,Do,Fr'::character varying,
    planned_hours numeric(4,2) DEFAULT 4.0,
    start_time time without time zone DEFAULT '07:00:00'::time without time zone,
    end_time time without time zone DEFAULT '11:00:00'::time without time zone,
    contact_person character varying(100),
    phone character varying(50),
    email character varying(100),
    emergency_phone character varying(50),
    key_location character varying(255),
    alarm_code character varying(50),
    special_instructions text,
    contract_start date,
    contract_end date,
    notes text,
    allowed_employees text,
    monthly_amount_netto numeric(8,2),
    monthly_amount_brutto numeric(8,2),
    vat_rate numeric(4,2) DEFAULT 19.0,
    payment_terms integer DEFAULT 30,
    invoice_day integer DEFAULT 1
);


ALTER TABLE public.objects OWNER TO seda24_user;

--
-- Name: schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedules (
    id integer NOT NULL,
    employee_id integer,
    object_id integer,
    weekday integer,
    start_time time without time zone,
    end_time time without time zone,
    planned_hours double precision,
    status character varying(20) DEFAULT 'normal'::character varying,
    replacement_for integer,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    color character varying(7),
    CONSTRAINT schedules_status_check CHECK (((status)::text = ANY ((ARRAY['normal'::character varying, 'urlaub'::character varying, 'krank'::character varying, 'vertretung'::character varying, 'storniert'::character varying])::text[])))
);


ALTER TABLE public.schedules OWNER TO postgres;

--
-- Name: current_week_schedule; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.current_week_schedule AS
 SELECT s.id,
    s.employee_id,
    s.object_id,
    s.weekday,
    s.start_time,
    s.end_time,
    s.planned_hours,
    s.status,
    s.replacement_for,
    s.notes,
    s.created_at,
    s.updated_at,
    s.created_by,
    s.color,
    (((e.first_name)::text || ' '::text) || (e.last_name)::text) AS employee_name,
    e.personal_nr,
    o.name AS object_name,
    c.name AS customer_name,
        CASE s.weekday
            WHEN 0 THEN 'Montag'::text
            WHEN 1 THEN 'Dienstag'::text
            WHEN 2 THEN 'Mittwoch'::text
            WHEN 3 THEN 'Donnerstag'::text
            WHEN 4 THEN 'Freitag'::text
            WHEN 5 THEN 'Samstag'::text
            WHEN 6 THEN 'Sonntag'::text
            ELSE NULL::text
        END AS weekday_name
   FROM (((public.schedules s
     JOIN public.employees e ON ((s.employee_id = e.id)))
     JOIN public.objects o ON ((s.object_id = o.id)))
     LEFT JOIN public.customers c ON ((o.customer_id = c.id)))
  WHERE (((s.status)::text <> 'storniert'::text) OR (s.status IS NULL))
  ORDER BY s.weekday, s.start_time;


ALTER TABLE public.current_week_schedule OWNER TO postgres;

--
-- Name: customer_hours; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_hours (
    id integer NOT NULL,
    customer_id integer,
    default_hours numeric(4,2) NOT NULL,
    cleaning_type character varying(20) DEFAULT 'unterhalt'::character varying,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.customer_hours OWNER TO postgres;

--
-- Name: customer_hours_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_hours_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_hours_id_seq OWNER TO postgres;

--
-- Name: customer_hours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_hours_id_seq OWNED BY public.customer_hours.id;


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: seda24_user
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customers_id_seq OWNER TO seda24_user;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seda24_user
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: employee_object_hours; Type: TABLE; Schema: public; Owner: seda24_user
--

CREATE TABLE public.employee_object_hours (
    id integer NOT NULL,
    employee_id integer,
    object_id integer,
    custom_hours double precision,
    created_at timestamp without time zone
);


ALTER TABLE public.employee_object_hours OWNER TO seda24_user;

--
-- Name: employee_object_hours_id_seq; Type: SEQUENCE; Schema: public; Owner: seda24_user
--

CREATE SEQUENCE public.employee_object_hours_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_object_hours_id_seq OWNER TO seda24_user;

--
-- Name: employee_object_hours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seda24_user
--

ALTER SEQUENCE public.employee_object_hours_id_seq OWNED BY public.employee_object_hours.id;


--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: seda24_user
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employees_id_seq OWNER TO seda24_user;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seda24_user
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: hourly_rates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hourly_rates (
    id integer NOT NULL,
    employee_id integer,
    rate_type character varying(30) NOT NULL,
    hourly_rate numeric(5,2) NOT NULL,
    valid_from date DEFAULT CURRENT_DATE
);


ALTER TABLE public.hourly_rates OWNER TO postgres;

--
-- Name: hourly_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hourly_rates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hourly_rates_id_seq OWNER TO postgres;

--
-- Name: hourly_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hourly_rates_id_seq OWNED BY public.hourly_rates.id;


--
-- Name: objects_id_seq; Type: SEQUENCE; Schema: public; Owner: seda24_user
--

CREATE SEQUENCE public.objects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.objects_id_seq OWNER TO seda24_user;

--
-- Name: objects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seda24_user
--

ALTER SEQUENCE public.objects_id_seq OWNED BY public.objects.id;


--
-- Name: quick_bookings; Type: TABLE; Schema: public; Owner: seda24_user
--

CREATE TABLE public.quick_bookings (
    id integer NOT NULL,
    employee_id integer,
    object_id integer,
    booking_date date,
    scheduled_hours double precision,
    booked_by integer,
    created_at timestamp without time zone,
    notes character varying
);


ALTER TABLE public.quick_bookings OWNER TO seda24_user;

--
-- Name: quick_bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: seda24_user
--

CREATE SEQUENCE public.quick_bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quick_bookings_id_seq OWNER TO seda24_user;

--
-- Name: quick_bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seda24_user
--

ALTER SEQUENCE public.quick_bookings_id_seq OWNED BY public.quick_bookings.id;


--
-- Name: replacement_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.replacement_rules (
    id integer NOT NULL,
    primary_employee_id integer,
    replacement_employee_id integer,
    priority integer DEFAULT 1,
    valid_from date,
    valid_until date,
    reason character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.replacement_rules OWNER TO postgres;

--
-- Name: replacement_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.replacement_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.replacement_rules_id_seq OWNER TO postgres;

--
-- Name: replacement_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.replacement_rules_id_seq OWNED BY public.replacement_rules.id;


--
-- Name: schedule_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_history (
    id integer NOT NULL,
    schedule_id integer,
    changed_by integer,
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    field_name character varying(50),
    old_value text,
    new_value text,
    change_reason text
);


ALTER TABLE public.schedule_history OWNER TO postgres;

--
-- Name: schedule_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schedule_history_id_seq OWNER TO postgres;

--
-- Name: schedule_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_history_id_seq OWNED BY public.schedule_history.id;


--
-- Name: schedule_template_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_template_items (
    id integer NOT NULL,
    template_id integer,
    employee_id integer,
    object_id integer,
    weekday character varying(20) NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    planned_hours numeric(4,2)
);


ALTER TABLE public.schedule_template_items OWNER TO postgres;

--
-- Name: schedule_template_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_template_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schedule_template_items_id_seq OWNER TO postgres;

--
-- Name: schedule_template_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_template_items_id_seq OWNED BY public.schedule_template_items.id;


--
-- Name: schedule_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_templates (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    is_active boolean DEFAULT true
);


ALTER TABLE public.schedule_templates OWNER TO postgres;

--
-- Name: schedule_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schedule_templates_id_seq OWNER TO postgres;

--
-- Name: schedule_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_templates_id_seq OWNED BY public.schedule_templates.id;


--
-- Name: schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schedules_id_seq OWNER TO postgres;

--
-- Name: schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedules_id_seq OWNED BY public.schedules.id;


--
-- Name: special_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.special_rules (
    id integer NOT NULL,
    employee_id integer,
    customer_id integer,
    special_hours numeric(4,2),
    special_rate numeric(5,2),
    note character varying(255),
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.special_rules OWNER TO postgres;

--
-- Name: special_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.special_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.special_rules_id_seq OWNER TO postgres;

--
-- Name: special_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.special_rules_id_seq OWNED BY public.special_rules.id;


--
-- Name: time_entries; Type: TABLE; Schema: public; Owner: seda24_user
--

CREATE TABLE public.time_entries (
    id integer NOT NULL,
    employee_id integer,
    object_id integer,
    check_in timestamp without time zone NOT NULL,
    check_out timestamp without time zone,
    check_in_lat double precision,
    check_in_lng double precision,
    check_out_lat double precision,
    check_out_lng double precision,
    is_manual_entry boolean,
    photo_url character varying,
    notes character varying,
    created_at timestamp without time zone,
    gps_lat double precision,
    gps_lng double precision,
    billed_hours double precision,
    service_type character varying DEFAULT 'Unterhaltsreinigung'::character varying,
    hourly_rate numeric(5,2) DEFAULT 15.00
);


ALTER TABLE public.time_entries OWNER TO seda24_user;

--
-- Name: time_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: seda24_user
--

CREATE SEQUENCE public.time_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.time_entries_id_seq OWNER TO seda24_user;

--
-- Name: time_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seda24_user
--

ALTER SEQUENCE public.time_entries_id_seq OWNED BY public.time_entries.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: seda24_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying,
    password_hash character varying,
    role public.userrole,
    is_active boolean,
    created_at timestamp without time zone,
    category character varying DEFAULT 'C'::character varying
);


ALTER TABLE public.users OWNER TO seda24_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: seda24_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO seda24_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seda24_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: warnings; Type: TABLE; Schema: public; Owner: seda24_user
--

CREATE TABLE public.warnings (
    id integer NOT NULL,
    employee_id integer,
    warning_type character varying,
    message character varying,
    is_resolved boolean,
    created_at timestamp without time zone,
    resolved_at timestamp without time zone
);


ALTER TABLE public.warnings OWNER TO seda24_user;

--
-- Name: warnings_id_seq; Type: SEQUENCE; Schema: public; Owner: seda24_user
--

CREATE SEQUENCE public.warnings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.warnings_id_seq OWNER TO seda24_user;

--
-- Name: warnings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seda24_user
--

ALTER SEQUENCE public.warnings_id_seq OWNED BY public.warnings.id;


--
-- Name: break_entries id; Type: DEFAULT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.break_entries ALTER COLUMN id SET DEFAULT nextval('public.break_entries_id_seq'::regclass);


--
-- Name: correction_requests id; Type: DEFAULT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.correction_requests ALTER COLUMN id SET DEFAULT nextval('public.correction_requests_id_seq'::regclass);


--
-- Name: customer_hours id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_hours ALTER COLUMN id SET DEFAULT nextval('public.customer_hours_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: employee_object_hours id; Type: DEFAULT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.employee_object_hours ALTER COLUMN id SET DEFAULT nextval('public.employee_object_hours_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: hourly_rates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hourly_rates ALTER COLUMN id SET DEFAULT nextval('public.hourly_rates_id_seq'::regclass);


--
-- Name: objects id; Type: DEFAULT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.objects ALTER COLUMN id SET DEFAULT nextval('public.objects_id_seq'::regclass);


--
-- Name: quick_bookings id; Type: DEFAULT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.quick_bookings ALTER COLUMN id SET DEFAULT nextval('public.quick_bookings_id_seq'::regclass);


--
-- Name: replacement_rules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.replacement_rules ALTER COLUMN id SET DEFAULT nextval('public.replacement_rules_id_seq'::regclass);


--
-- Name: schedule_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_history ALTER COLUMN id SET DEFAULT nextval('public.schedule_history_id_seq'::regclass);


--
-- Name: schedule_template_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_template_items ALTER COLUMN id SET DEFAULT nextval('public.schedule_template_items_id_seq'::regclass);


--
-- Name: schedule_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_templates ALTER COLUMN id SET DEFAULT nextval('public.schedule_templates_id_seq'::regclass);


--
-- Name: schedules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules ALTER COLUMN id SET DEFAULT nextval('public.schedules_id_seq'::regclass);


--
-- Name: special_rules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.special_rules ALTER COLUMN id SET DEFAULT nextval('public.special_rules_id_seq'::regclass);


--
-- Name: time_entries id; Type: DEFAULT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.time_entries ALTER COLUMN id SET DEFAULT nextval('public.time_entries_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: warnings id; Type: DEFAULT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.warnings ALTER COLUMN id SET DEFAULT nextval('public.warnings_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: seda24_user
--

COPY public.alembic_version (version_num) FROM stdin;
14c5751f84d1
\.


--
-- Data for Name: break_entries; Type: TABLE DATA; Schema: public; Owner: seda24_user
--

COPY public.break_entries (id, time_entry_id, start_time, end_time, is_paid, break_type) FROM stdin;
\.


--
-- Data for Name: correction_requests; Type: TABLE DATA; Schema: public; Owner: seda24_user
--

COPY public.correction_requests (id, employee_id, time_entry_id, correction_type, old_value, new_value, reason, status, admin_response, processed_by, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: customer_hours; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_hours (id, customer_id, default_hours, cleaning_type, created_at) FROM stdin;
1	2	5.00	unterhalt	2025-09-02 06:18:57.144958
2	3	4.00	unterhalt	2025-09-02 06:18:57.144958
3	4	6.00	unterhalt	2025-09-02 06:18:57.144958
4	5	3.00	unterhalt	2025-09-02 06:20:22.307878
5	6	4.00	unterhalt	2025-09-02 06:20:22.307878
6	7	2.00	unterhalt	2025-09-02 06:20:22.307878
7	9	5.00	unterhalt	2025-09-02 06:20:22.307878
8	10	2.00	unterhalt	2025-09-02 06:20:22.307878
9	11	8.00	unterhalt	2025-09-02 06:20:22.307878
10	12	3.00	unterhalt	2025-09-02 06:20:22.307878
11	13	4.00	unterhalt	2025-09-02 06:20:22.307878
12	14	3.00	unterhalt	2025-09-02 06:20:22.307878
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: seda24_user
--

COPY public.customers (id, name, address, billing_type, monthly_rate, created_at, is_active) FROM stdin;
2	Lidl Bietigheim	\N	pauschale	\N	2025-08-22 20:03:43.196054	t
3	Enfido	\N	pauschale	\N	2025-08-22 20:03:43.203646	t
4	Metalicone	\N	pauschale	\N	2025-08-22 20:03:43.210347	t
5	JU_RA	\N	pauschale	\N	2025-08-22 20:03:43.213633	t
6	Huber	\N	pauschale	\N	2025-08-22 20:03:43.216481	t
7	BAD-Treppen	\N	pauschale	\N	2025-08-22 20:03:43.219342	t
8	Seda GmbH	\N	pauschale	\N	2025-08-22 20:03:43.222127	t
9	Leible GmbH	\N	pauschale	\N	2025-08-22 20:03:43.224887	t
10	Zinsfabrik	\N	pauschale	\N	2025-08-22 20:03:43.227226	t
11	Polytec	\N	pauschale	\N	2025-08-22 20:03:43.229754	t
12	Steuerberater BB	\N	pauschale	\N	2025-08-22 20:03:43.232248	t
13	Geiger GmbH	\N	pauschale	\N	2025-08-22 20:03:43.234751	t
14	Rytec	\N	pauschale	\N	2025-08-22 20:03:43.237139	t
\.


--
-- Data for Name: employee_object_hours; Type: TABLE DATA; Schema: public; Owner: seda24_user
--

COPY public.employee_object_hours (id, employee_id, object_id, custom_hours, created_at) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: seda24_user
--

COPY public.employees (id, user_id, personal_nr, first_name, last_name, hourly_rate, kuerzel, monthly_amount, address, gps_required, auto_stamp, is_active, created_at, hourly_rate_standard, hourly_rate_window, hourly_rate_basic, tracking_mode, start_hours, employment_type, max_monthly_amount, total_hours_since_start) FROM stdin;
10	36	D0032	Andreas	Frosch	15	Andy	556	Draisstr. 14, 76437 Rastatt	f	f	t	2025-08-20 10:42:05.622798	15	20	20	B	390.30	minijob	556.00	390.3
7	33	D0025	Eldina	Mustafic	15	Eldina	556	Frühlingstr. 24, 76456 Kuppenheim	f	f	t	2025-08-20 10:42:04.755014	15	20	20	C	784.30	minijob	556.00	784.3
9	35	D0031	Eliane	DaSilvaTodaro	15	Elia	556	Draisstr. 14, 76437 Rastatt	t	f	t	2025-08-20 10:42:05.331241	15	20	20	C	344.50	minijob	556.00	344.5
8	34	D0022	Jana	Bojko	15	Jana	556	Brufertstr. 9, 76437 Rastatt	f	f	t	2025-08-20 10:42:05.044385	15	20	20	C	374.50	minijob	556.00	374.5
5	31	D0004	Ljubica	Stjepic	15	Ljubica	556	Oberndorfstr. 2, 76456 Kuppenheim	f	f	t	2025-08-20 10:42:04.180445	15	20	20	B	1099.90	minijob	556.00	1099.9
6	32	D0021	Matej	Stjepic	15	Matko	556	Wieslesweg 9, 76332 Bad Herrenalb	f	f	t	2025-08-20 10:42:04.466934	15	20	20	B	1174.60	minijob	556.00	1174.6
17	41	D0034	Sonja	Mutlak	15	\N	556	\N	f	f	t	2025-08-25 09:42:31.415987	15	20	20	C	4.50	minijob	556.00	4.5
4	30	D0002	Ruzica	Sertic	20	Ruza	2000	Zeppelinstr. 42, 76571 Gaggenau	f	f	t	2025-08-20 10:42:03.878514	17	20	20	A	4669.80	teilzeit	556.00	4669.8
16	40	D0001	Drazen	Sertic	22	\N	556	\N	f	f	t	2025-08-22 18:04:39.97645	26	30	30	A	141.80	chef	556.00	141.8
19	48	D0036	Ddado	dado	15	\N	556	\N	t	f	t	2025-09-07 16:58:33.530348	15	20	20	C	0.00	minijob	556.00	0
1	1	A0001	Admin	SEDA24	25	\N	556	\N	f	f	t	2025-08-20 10:41:38.229567	15	20	20	C	0.00	admin	556.00	0
22	51	D0037	Testing	Test	15	\N	556	\N	t	f	t	2025-09-07 17:04:38.386657	15	20	20	C	0.00	minijob	556.00	0
23	52	D0040	Bitcoin	Nue	15	\N	556	\N	t	f	t	2025-09-07 17:05:43.893098	15	20	20	B	0.00	minijob	556.00	0
\.


--
-- Data for Name: hourly_rates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hourly_rates (id, employee_id, rate_type, hourly_rate, valid_from) FROM stdin;
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: public; Owner: seda24_user
--

COPY public.objects (id, customer_id, name, address, gps_lat, gps_lng, radius_meters, created_at, is_active, radius_m, cleaning_type, monthly_amount, cleaning_interval, cleaning_days, planned_hours, start_time, end_time, contact_person, phone, email, emergency_phone, key_location, alarm_code, special_instructions, contract_start, contract_end, notes, allowed_employees, monthly_amount_netto, monthly_amount_brutto, vat_rate, payment_terms, invoice_day) FROM stdin;
4	2	Lidl Wochenende	Muggensturmer Straße 2, 76467 Bietigheim	48.8888214774413	8.26481250682591	\N	2025-08-22 20:03:43.205729	t	100	\N	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
5	3	Enfido Sonnenschein	Im Sonnenschein 3, 76467 Bietigheim	48.9090646883034	8.26101850482367	\N	2025-08-22 20:03:43.211377	t	100	\N	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
6	4	Metalicone Muggensturm	Henkelstr. 14, 76461 Muggensturm	48.8797133935092	8.28035636486564	\N	2025-08-22 20:03:43.214258	t	100	\N	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
7	5	JU_RA Baden-Baden	Markgrafenstr. 28, 76530 Baden-Baden	48.761231974953	8.25051555347136	\N	2025-08-22 20:03:43.217158	t	100	\N	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
8	6	Huber Iffezheim	Südring 11, 76473 Iffezheim	48.816710389053	8.15985572143728	\N	2025-08-22 20:03:43.219949	t	100	\N	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
9	7	BAD-Treppen	Hardäckerstr. 2, 76530 Baden-Baden	48.7576771385761	8.24505946642259	\N	2025-08-22 20:03:43.222676	t	100	\N	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
11	9	Leible Rheinmünster	Körnersbühnd 2, 77836 Rheinmünster	48.7498572046747	8.03728945082595	\N	2025-08-22 20:03:43.227806	t	100	\N	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
12	10	Zinsfabrik Baden-Baden	Lange Str. 61, 76530 Baden-Baden	48.7664297331785	8.23475597645378	\N	2025-08-22 20:03:43.230356	t	100	\N	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
13	11	Polytec Rastatt	Karlsruher Strasse 33, 76437 Rastatt	48.8657781551626	8.22110284976376	\N	2025-08-22 20:03:43.232808	t	100	\N	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
14	12	Steuerberater Baden-Baden	Prinz-Weimar-Str. 12, 76530 Baden-Baden	48.7611535126502	8.24928112428465	\N	2025-08-22 20:03:43.235318	t	100	\N	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
15	13	Geiger Malsch	Dieselstr. 9, 76316 Malsch	48.8894361838853	8.31018689424884	\N	2025-08-22 20:03:43.23767	t	100	\N	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
16	14	Rytec Baden-Baden	Pariser Ring 37, 76532 Baden-Baden	48.7783217330924	8.20291705679789	\N	2025-08-22 20:03:43.238689	t	100	\N	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
1	8	SEDA24 Zentrale	Zeppelinstr. 42, 76571 Gaggenau	48.794968	8.310615	\N	\N	\N	100	office	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
17	8	TEST-OBJEKT-999	\N	\N	\N	\N	\N	\N	100	Grundreinigung	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
18	8	TEST-OBJEKT-999	\N	\N	\N	\N	\N	\N	100	Grundreinigung	\N	täglich	Mo,Di,Mi,Do,Fr	4.00	07:00:00	11:00:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
3	2	Lidl Muggensturmer Str	Muggensturmer Straße 2, 76467 Bietigheim	48.8888214774413	8.26481250682591	\N	2025-08-22 20:03:43.205727	t	100	\N	\N	täglich	Mo,Di,Mi,Do,Fr	5.00	07:00:00	11:00:00	Herr Schmidt	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	19.00	30	1
\.


--
-- Data for Name: quick_bookings; Type: TABLE DATA; Schema: public; Owner: seda24_user
--

COPY public.quick_bookings (id, employee_id, object_id, booking_date, scheduled_hours, booked_by, created_at, notes) FROM stdin;
\.


--
-- Data for Name: replacement_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.replacement_rules (id, primary_employee_id, replacement_employee_id, priority, valid_from, valid_until, reason, created_at) FROM stdin;
\.


--
-- Data for Name: schedule_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_history (id, schedule_id, changed_by, changed_at, field_name, old_value, new_value, change_reason) FROM stdin;
\.


--
-- Data for Name: schedule_template_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_template_items (id, template_id, employee_id, object_id, weekday, start_time, end_time, planned_hours) FROM stdin;
\.


--
-- Data for Name: schedule_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_templates (id, name, description, created_at, created_by, is_active) FROM stdin;
\.


--
-- Data for Name: schedules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedules (id, employee_id, object_id, weekday, start_time, end_time, planned_hours, status, replacement_for, notes, created_at, updated_at, created_by, color) FROM stdin;
601	4	3	1	15:00:00	20:00:00	5	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
602	4	3	2	15:00:00	20:00:00	5	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
603	4	3	3	15:00:00	20:00:00	5	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
604	4	4	6	11:00:00	13:00:00	2	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
605	4	15	6	13:30:00	17:30:00	4	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
606	5	14	6	09:00:00	15:00:00	6	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
607	5	13	6	16:00:00	19:00:00	3	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
608	6	5	3	17:30:00	20:00:00	2.5	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
609	6	14	6	09:00:00	15:00:00	6	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
610	6	12	5	17:00:00	19:30:00	2.5	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
611	7	3	1	15:00:00	20:00:00	4	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
612	7	3	2	15:00:00	20:00:00	4	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
613	8	6	6	18:00:00	20:45:00	2.75	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
614	9	9	1	11:00:00	12:30:00	1.5	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
615	9	9	2	11:00:00	12:30:00	1.5	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
616	9	1	5	11:30:00	17:30:00	6	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
617	9	12	5	17:00:00	19:30:00	2.5	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
618	10	11	3	20:45:00	23:45:00	3	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
619	10	12	3	17:00:00	19:30:00	2.5	normal	\N	\N	2025-09-06 18:07:35.638694	2025-09-06 18:07:35.638694	\N	\N
\.


--
-- Data for Name: special_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.special_rules (id, employee_id, customer_id, special_hours, special_rate, note, active, created_at) FROM stdin;
1	7	2	4.00	\N	Eldina bei Lidl nur 4h statt 5h	t	2025-09-02 06:18:57.147909
2	4	4	7.00	\N	Ruza bei Metalicone 7h statt 6h - Chefin macht mehr	t	2025-09-02 06:25:19.74269
3	16	2	6.00	\N	Drazen bei Lidl 6h - Chef kontrolliert	t	2025-09-02 06:25:19.74269
4	16	3	5.00	\N	Drazen bei Enfido 5h statt 4h	t	2025-09-02 06:25:19.74269
\.


--
-- Data for Name: time_entries; Type: TABLE DATA; Schema: public; Owner: seda24_user
--

COPY public.time_entries (id, employee_id, object_id, check_in, check_out, check_in_lat, check_in_lng, check_out_lat, check_out_lng, is_manual_entry, photo_url, notes, created_at, gps_lat, gps_lng, billed_hours, service_type, hourly_rate) FROM stdin;
140	4	1	2025-08-24 07:07:51.503879	2025-08-24 07:08:10.935324	\N	\N	\N	\N	f	\N	\N	2025-08-24 07:07:51.504443	\N	\N	\N	Unterhaltsreinigung	15.00
141	4	1	2025-08-24 07:10:15.14117	2025-08-24 07:10:33.239764	\N	\N	\N	\N	f	\N	\N	2025-08-24 07:10:15.142672	\N	\N	\N	Unterhaltsreinigung	15.00
142	4	1	2025-08-24 07:12:52.6846	2025-08-24 07:13:28.891858	\N	\N	\N	\N	f	\N	\N	2025-08-24 07:12:52.685083	\N	\N	\N	Unterhaltsreinigung	15.00
143	4	1	2025-08-24 07:13:34.037855	2025-08-24 07:18:10.702589	\N	\N	\N	\N	f	\N	\N	2025-08-24 07:13:34.038341	\N	\N	\N	Unterhaltsreinigung	15.00
144	4	1	2025-08-24 07:18:23.893943	2025-08-24 07:20:02.545348	\N	\N	\N	\N	f	\N	\N	2025-08-24 07:18:23.894425	\N	\N	\N	Unterhaltsreinigung	15.00
145	4	1	2025-08-24 07:23:26.848875	2025-08-24 07:51:10.950101	\N	\N	\N	\N	f	\N	\N	2025-08-24 07:23:26.85055	\N	\N	\N	Unterhaltsreinigung	15.00
146	4	1	2025-08-24 07:51:44.395339	2025-08-24 07:51:57.584784	\N	\N	\N	\N	f	\N	\N	2025-08-24 07:51:44.396707	\N	\N	\N	Unterhaltsreinigung	15.00
147	4	1	2025-08-24 07:52:01.223163	2025-08-24 07:52:56.436333	\N	\N	\N	\N	f	\N	\N	2025-08-24 07:52:01.223565	\N	\N	\N	Unterhaltsreinigung	15.00
148	4	1	2025-08-24 07:53:01.775934	2025-08-24 07:53:41.426458	\N	\N	\N	\N	f	\N	\N	2025-08-24 07:53:01.776403	\N	\N	\N	Unterhaltsreinigung	15.00
149	4	5	2025-08-24 07:53:51.675432	2025-08-24 07:54:21.19454	\N	\N	\N	\N	f	\N	\N	2025-08-24 07:53:51.676739	\N	\N	\N	Unterhaltsreinigung	15.00
139	1	1	2025-08-23 21:16:55.80918	2025-08-24 07:57:58.490582	\N	\N	\N	\N	f	\N	\N	2025-08-23 21:16:55.809654	\N	\N	\N	Unterhaltsreinigung	15.00
150	4	1	2025-08-24 07:54:44.119165	2025-08-24 07:57:58.50139	\N	\N	\N	\N	f	\N	\N	2025-08-24 07:54:44.119579	\N	\N	\N	Unterhaltsreinigung	15.00
151	4	1	2025-08-24 07:58:55.718311	2025-08-24 08:02:11.029722	\N	\N	\N	\N	f	\N	\N	2025-08-24 07:58:55.719871	\N	\N	\N	Unterhaltsreinigung	15.00
152	4	1	2025-08-24 08:03:25.095101	2025-08-24 08:03:42.410868	\N	\N	\N	\N	f	\N	\N	2025-08-24 08:03:25.095519	\N	\N	\N	Unterhaltsreinigung	15.00
153	4	1	2025-08-24 08:05:15.141972	2025-08-24 08:05:19.556449	\N	\N	\N	\N	f	\N	\N	2025-08-24 08:05:15.142403	\N	\N	\N	Unterhaltsreinigung	15.00
154	4	1	2025-08-24 08:18:33.378181	2025-08-24 08:20:47.455201	\N	\N	\N	\N	f	\N	\N	2025-08-24 08:18:33.379768	\N	\N	\N	Unterhaltsreinigung	15.00
155	4	1	2025-08-24 08:20:51.167617	2025-08-24 08:21:24.971381	\N	\N	\N	\N	f	\N	\N	2025-08-24 08:20:51.168073	\N	\N	\N	Unterhaltsreinigung	15.00
156	4	1	2025-08-24 08:24:43.779462	2025-08-24 08:24:55.065071	\N	\N	\N	\N	f	\N	\N	2025-08-24 08:24:43.781023	\N	\N	\N	Unterhaltsreinigung	15.00
157	4	1	2025-08-24 08:24:56.346008	2025-08-24 08:42:29.274104	\N	\N	\N	\N	f	\N	\N	2025-08-24 08:24:56.346475	\N	\N	\N	Unterhaltsreinigung	15.00
158	4	5	2025-08-24 08:42:38.56834	2025-08-24 09:05:21.378044	\N	\N	\N	\N	f	\N	\N	2025-08-24 08:42:38.568803	\N	\N	\N	Unterhaltsreinigung	15.00
159	4	15	2025-08-24 09:05:47.308075	2025-08-24 09:11:01.796844	\N	\N	\N	\N	f	\N	\N	2025-08-24 09:05:47.308445	\N	\N	\N	Unterhaltsreinigung	15.00
131	1	1	2025-08-23 20:29:39.84041	2025-08-23 20:29:53.330782	\N	\N	\N	\N	f	\N	\N	2025-08-23 20:29:39.842017	\N	\N	\N	Unterhaltsreinigung	15.00
132	1	1	2025-08-23 20:30:04.858061	2025-08-23 20:30:43.97403	\N	\N	\N	\N	f	\N	\N	2025-08-23 20:30:04.858461	\N	\N	\N	Unterhaltsreinigung	15.00
133	1	12	2025-08-23 20:30:45.349117	2025-08-23 20:30:47.39391	\N	\N	\N	\N	f	\N	\N	2025-08-23 20:30:45.349483	\N	\N	\N	Unterhaltsreinigung	15.00
135	4	1	2025-08-23 20:39:20.025442	2025-08-23 20:54:17.480352	\N	\N	\N	\N	f	\N	\N	2025-08-23 20:39:20.02586	\N	\N	\N	Unterhaltsreinigung	15.00
136	4	6	2025-08-23 20:54:22.692346	2025-08-23 20:54:33.097882	\N	\N	\N	\N	f	\N	\N	2025-08-23 20:54:22.692734	\N	\N	\N	Unterhaltsreinigung	15.00
134	1	12	2025-08-23 20:32:11.306906	2025-08-23 20:58:42.880612	\N	\N	\N	\N	f	\N	\N	2025-08-23 20:32:11.307335	\N	\N	\N	Unterhaltsreinigung	15.00
137	4	11	2025-08-23 21:05:33.159187	2025-08-23 21:11:42.111679	\N	\N	\N	\N	f	\N	\N	2025-08-23 21:05:33.160786	\N	\N	\N	Unterhaltsreinigung	15.00
138	4	3	2025-08-23 21:11:46.926416	2025-08-24 07:06:33.669776	\N	\N	\N	\N	f	\N	\N	2025-08-23 21:11:46.926858	\N	\N	\N	Unterhaltsreinigung	15.00
161	1	1	2025-08-24 11:34:35.7013	2025-08-24 16:07:25.992817	\N	\N	\N	\N	f	\N	\N	2025-08-24 11:34:35.703181	\N	\N	\N	Unterhaltsreinigung	15.00
162	1	13	2025-08-24 16:11:23.755228	2025-08-25 13:24:00.606987	\N	\N	\N	\N	f	\N	\N	2025-08-24 16:11:23.755663	\N	\N	\N	Unterhaltsreinigung	15.00
163	1	1	2025-08-25 13:24:36.339656	2025-08-25 13:25:07.111914	\N	\N	\N	\N	f	\N	\N	2025-08-25 13:24:36.341012	\N	\N	\N	Unterhaltsreinigung	15.00
164	10	1	2025-08-25 13:43:02.80048	2025-08-25 14:10:58.362052	\N	\N	\N	\N	f	\N	\N	2025-08-25 13:43:02.802038	\N	\N	\N	Unterhaltsreinigung	15.00
165	6	3	2025-08-25 14:11:16.492218	2025-08-25 14:15:50.5077	\N	\N	\N	\N	f	\N	\N	2025-08-25 14:11:16.492748	\N	\N	\N	Unterhaltsreinigung	15.00
160	16	1	2025-08-24 09:23:06.500409	2025-08-26 07:06:37.353636	\N	\N	\N	\N	f	\N	\N	2025-08-24 09:23:06.50207	\N	\N	\N	Unterhaltsreinigung	15.00
166	16	1	2025-08-26 07:06:42.300585	2025-08-26 09:13:43.885617	\N	\N	\N	\N	f	\N	\N	2025-08-26 07:06:42.301909	\N	\N	\N	Unterhaltsreinigung	15.00
167	16	1	2025-08-26 09:13:49.192831	2025-08-26 09:43:52.869613	\N	\N	\N	\N	f	\N	\N	2025-08-26 09:13:49.194166	\N	\N	\N	Unterhaltsreinigung	15.00
168	16	1	2025-08-26 10:12:29.90097	2025-08-26 11:47:50.415993	\N	\N	\N	\N	f	\N	\N	2025-08-26 10:12:29.90252	\N	\N	\N	Unterhaltsreinigung	15.00
169	16	1	2025-08-26 12:14:21.835639	2025-08-26 12:14:29.611261	\N	\N	\N	\N	f	\N	\N	2025-08-26 12:14:21.837139	\N	\N	\N	Unterhaltsreinigung	15.00
170	10	1	2025-08-26 14:03:11.859105	2025-08-26 14:04:22.985459	\N	\N	\N	\N	f	\N	\N	2025-08-26 14:03:11.859578	\N	\N	\N	Unterhaltsreinigung	15.00
171	10	11	2025-08-26 14:28:08.130609	2025-08-26 14:28:30.506999	\N	\N	\N	\N	f	\N	\N	2025-08-26 14:28:08.131097	\N	\N	\N	Unterhaltsreinigung	15.00
172	10	1	2025-08-26 14:54:13.018204	2025-08-26 14:54:21.59023	\N	\N	\N	\N	f	\N	\N	2025-08-26 14:54:13.018615	\N	\N	\N	Unterhaltsreinigung	15.00
173	10	1	2025-08-26 14:55:11.610686	2025-08-26 14:56:12.906464	\N	\N	\N	\N	f	\N	\N	2025-08-26 14:55:11.611086	\N	\N	\N	Unterhaltsreinigung	15.00
174	10	8	2025-08-26 14:56:19.577162	2025-08-26 17:30:52.358222	\N	\N	\N	\N	f	\N	\N	2025-08-26 14:56:19.577554	\N	\N	\N	Unterhaltsreinigung	15.00
176	16	1	2025-08-26 17:37:42.312738	2025-08-26 18:16:01.56962	\N	\N	\N	\N	f	\N	\N	2025-08-26 17:37:42.313223	\N	\N	\N	Unterhaltsreinigung	15.00
175	10	1	2025-08-26 17:37:06.774233	2025-08-26 18:16:09.724885	\N	\N	\N	\N	f	\N	\N	2025-08-26 17:37:06.775879	\N	\N	\N	Unterhaltsreinigung	15.00
178	10	1	2025-08-26 18:35:15.231531	2025-08-26 18:35:18.52937	\N	\N	\N	\N	f	\N	\N	2025-08-26 18:35:15.233108	\N	\N	\N	Unterhaltsreinigung	15.00
177	6	1	2025-08-26 18:16:18.434944	2025-08-26 18:43:05.682976	\N	\N	\N	\N	f	\N	\N	2025-08-26 18:16:18.435333	\N	\N	\N	Unterhaltsreinigung	15.00
179	10	11	2025-08-26 18:58:02.64141	2025-08-26 18:58:29.00499	\N	\N	\N	\N	f	\N	\N	2025-08-26 18:58:02.643091	\N	\N	\N	Unterhaltsreinigung	15.00
180	16	1	2025-08-26 19:38:16.763074	2025-08-26 19:54:38.735004	\N	\N	\N	\N	f	\N	\N	2025-08-26 19:38:16.764718	\N	\N	\N	Unterhaltsreinigung	15.00
181	1	1	2025-08-26 20:44:04.350353	2025-08-26 20:44:39.163697	\N	\N	\N	\N	f	\N	\N	2025-08-26 20:44:04.352051	\N	\N	\N	Unterhaltsreinigung	15.00
182	1	1	2025-08-26 21:21:34.895754	2025-08-26 21:21:43.36922	\N	\N	\N	\N	f	\N	\N	2025-08-26 21:21:34.896278	\N	\N	\N	Unterhaltsreinigung	15.00
183	6	1	2025-08-28 09:43:37.507105	2025-08-28 09:43:37.552391	\N	\N	\N	\N	f	\N	\N	2025-08-28 09:43:37.508686	\N	\N	\N	Unterhaltsreinigung	15.00
184	6	1	2025-08-28 09:43:37.5601	2025-08-28 09:43:37.692262	\N	\N	\N	\N	f	\N	\N	2025-08-28 09:43:37.560486	\N	\N	\N	Unterhaltsreinigung	15.00
185	6	1	2025-08-28 09:43:37.850083	2025-08-28 09:43:38.664611	\N	\N	\N	\N	f	\N	\N	2025-08-28 09:43:37.850444	\N	\N	\N	Unterhaltsreinigung	15.00
186	6	1	2025-08-28 09:43:39.166666	2025-08-28 09:46:28.156382	\N	\N	\N	\N	f	\N	\N	2025-08-28 09:43:39.16707	\N	\N	\N	Unterhaltsreinigung	15.00
187	16	1	2025-08-28 09:51:22.816991	2025-08-28 09:53:19.334673	\N	\N	\N	\N	f	\N	\N	2025-08-28 09:51:22.817385	\N	\N	\N	Unterhaltsreinigung	15.00
188	16	1	2025-08-28 09:53:23.225674	2025-08-29 08:57:39.938141	\N	\N	\N	\N	f	\N	\N	2025-08-28 09:53:23.226097	\N	\N	\N	Unterhaltsreinigung	15.00
189	16	1	2025-08-29 08:57:41.842026	2025-08-29 10:34:05.47778	\N	\N	\N	\N	f	\N	\N	2025-08-29 08:57:41.843401	\N	\N	\N	Unterhaltsreinigung	15.00
190	16	1	2025-08-29 10:35:20.209171	2025-08-29 10:53:09.729942	\N	\N	\N	\N	f	\N	\N	2025-08-29 10:35:20.209737	\N	\N	\N	Unterhaltsreinigung	15.00
191	16	12	2025-08-29 10:53:17.220478	2025-08-29 10:53:29.176925	\N	\N	\N	\N	f	\N	\N	2025-08-29 10:53:17.221833	\N	\N	\N	Unterhaltsreinigung	15.00
192	16	12	2025-08-29 10:53:30.891926	2025-08-29 11:08:27.485426	\N	\N	\N	\N	f	\N	\N	2025-08-29 10:53:30.892371	\N	\N	\N	Unterhaltsreinigung	15.00
193	16	12	2025-08-29 11:08:34.153064	2025-08-29 11:10:08.396561	\N	\N	\N	\N	f	\N	\N	2025-08-29 11:08:34.153535	\N	\N	\N	Unterhaltsreinigung	15.00
194	16	1	2025-08-29 11:10:14.464149	2025-08-29 11:32:21.818048	\N	\N	\N	\N	f	\N	\N	2025-08-29 11:10:14.46557	\N	\N	\N	Unterhaltsreinigung	15.00
195	16	8	2025-08-29 11:32:41.253667	2025-08-29 13:24:52.86678	\N	\N	\N	\N	f	\N	\N	2025-08-29 11:32:41.254981	\N	\N	\N	Unterhaltsreinigung	15.00
196	16	1	2025-08-29 13:29:40.536972	2025-08-29 13:34:48.912135	\N	\N	\N	\N	f	\N	\N	2025-08-29 13:29:40.538556	\N	\N	\N	Unterhaltsreinigung	15.00
197	16	1	2025-08-29 14:54:19.36765	2025-08-29 15:01:50.64525	\N	\N	\N	\N	f	\N	\N	2025-08-29 14:54:19.369171	\N	\N	\N	Unterhaltsreinigung	15.00
198	16	4	2025-08-29 15:02:15.349517	2025-08-29 15:11:21.256875	\N	\N	\N	\N	f	\N	\N	2025-08-29 15:02:15.350821	\N	\N	\N	Unterhaltsreinigung	15.00
199	16	4	2025-08-29 15:13:12.125178	2025-08-29 15:15:18.297853	\N	\N	\N	\N	f	\N	\N	2025-08-29 15:13:12.12666	\N	\N	\N	Unterhaltsreinigung	15.00
200	16	1	2025-08-29 15:25:59.199997	2025-08-29 15:29:22.946175	\N	\N	\N	\N	f	\N	\N	2025-08-29 15:25:59.201562	\N	\N	\N	Unterhaltsreinigung	15.00
201	16	1	2025-08-29 15:29:28.529629	2025-08-29 15:29:32.813176	\N	\N	\N	\N	f	\N	\N	2025-08-29 15:29:28.531043	\N	\N	\N	Unterhaltsreinigung	15.00
202	16	1	2025-08-29 15:29:36.834412	2025-08-29 15:57:20.687815	\N	\N	\N	\N	f	\N	\N	2025-08-29 15:29:36.834962	\N	\N	\N	Unterhaltsreinigung	15.00
203	16	1	2025-08-29 15:57:24.797238	2025-08-29 16:00:36.74717	\N	\N	\N	\N	f	\N	\N	2025-08-29 15:57:24.798592	\N	\N	\N	Unterhaltsreinigung	15.00
205	10	8	2025-08-29 17:52:41.029101	2025-08-29 18:07:57.941888	\N	\N	\N	\N	f	\N	\N	2025-08-29 17:52:41.030956	\N	\N	\N	Unterhaltsreinigung	15.00
204	16	1	2025-08-29 16:30:43.427315	2025-08-29 20:40:36.447406	\N	\N	\N	\N	f	\N	 | Wechsel zu Objekt 12	2025-08-29 16:30:43.429026	\N	\N	\N	Unterhaltsreinigung	15.00
206	16	12	2025-08-29 20:40:36.44744	2025-08-29 20:41:09.480209	\N	\N	\N	\N	f	\N	Wechsel von Objekt 1 | Wechsel zu Objekt 3	2025-08-29 20:40:36.456771	\N	\N	\N	Unterhaltsreinigung	15.00
207	16	3	2025-08-29 20:41:09.480233	2025-08-29 20:44:08.038799	\N	\N	\N	\N	f	\N	Wechsel von Objekt 12 | Wechsel zu Objekt 14	2025-08-29 20:41:09.481341	\N	\N	\N	Unterhaltsreinigung	15.00
208	16	14	2025-08-29 20:44:08.038835	2025-08-29 20:44:19.428221	\N	\N	\N	\N	f	\N	Wechsel von Objekt 3 | Wechsel zu Objekt 3	2025-08-29 20:44:08.041973	\N	\N	\N	Unterhaltsreinigung	15.00
209	16	3	2025-08-29 20:44:19.428261	2025-08-29 20:45:20.965374	\N	\N	\N	\N	f	\N	Wechsel von Objekt 14 | Wechsel zu Objekt 16	2025-08-29 20:44:19.429455	\N	\N	\N	Unterhaltsreinigung	15.00
210	16	16	2025-08-29 20:45:20.965412	2025-08-29 20:49:06.80145	\N	\N	\N	\N	f	\N	Wechsel von Objekt 3 | Wechsel zu Objekt 3	2025-08-29 20:45:20.966638	\N	\N	\N	Unterhaltsreinigung	15.00
211	16	3	2025-08-29 20:49:06.801484	2025-08-29 20:49:14.980483	\N	\N	\N	\N	f	\N	Wechsel von Objekt 16 | Wechsel zu Objekt 11	2025-08-29 20:49:06.804466	\N	\N	\N	Unterhaltsreinigung	15.00
212	16	11	2025-08-29 20:49:14.980508	2025-08-29 20:53:32.089221	\N	\N	\N	\N	f	\N	Wechsel von Objekt 3 | Wechsel zu Objekt 5	2025-08-29 20:49:14.981514	\N	\N	\N	Unterhaltsreinigung	15.00
213	16	5	2025-08-29 20:53:32.089308	2025-08-29 20:53:43.881305	\N	\N	\N	\N	f	\N	Wechsel von Objekt 11 | Wechsel zu Objekt 3	2025-08-29 20:53:32.092192	\N	\N	\N	Unterhaltsreinigung	15.00
214	16	3	2025-08-29 20:53:43.881344	2025-08-29 20:53:47.18458	\N	\N	\N	\N	f	\N	Wechsel von Objekt 5 | Wechsel zu Objekt 3	2025-08-29 20:53:43.882382	\N	\N	\N	Unterhaltsreinigung	15.00
215	16	3	2025-08-29 20:53:47.184599	2025-08-29 21:00:51.996664	\N	\N	\N	\N	f	\N	Wechsel von Objekt 3 | Wechsel zu Objekt 14	2025-08-29 20:53:47.185851	\N	\N	\N	Unterhaltsreinigung	15.00
216	16	14	2025-08-29 21:00:51.996683	2025-08-29 21:01:03.908	\N	\N	\N	\N	f	\N	Wechsel von Objekt 3 | Wechsel zu Objekt 4	2025-08-29 21:00:51.997817	\N	\N	\N	Unterhaltsreinigung	15.00
217	16	4	2025-08-29 21:01:03.908019	2025-08-29 21:08:37.827616	\N	\N	\N	\N	f	\N	Wechsel von Objekt 14 | Wechsel zu Objekt 16	2025-08-29 21:01:03.908943	\N	\N	\N	Unterhaltsreinigung	15.00
218	16	16	2025-08-29 21:08:37.82765	2025-08-29 21:30:33.297603	\N	\N	\N	\N	f	\N	Wechsel von Objekt 4 | Wechsel zu Objekt 16	2025-08-29 21:08:37.830772	\N	\N	\N	Unterhaltsreinigung	15.00
219	16	16	2025-08-29 21:30:33.297635	2025-08-29 21:30:39.47799	\N	\N	\N	\N	f	\N	Wechsel von Objekt 16 | Wechsel zu Objekt 14	2025-08-29 21:30:33.298894	\N	\N	\N	Unterhaltsreinigung	15.00
220	16	14	2025-08-29 21:30:39.478011	2025-08-29 21:30:57.307018	\N	\N	\N	\N	f	\N	Wechsel von Objekt 16 | Wechsel zu Objekt 15	2025-08-29 21:30:39.479052	\N	\N	\N	Unterhaltsreinigung	15.00
221	16	15	2025-08-29 21:30:57.30704	2025-08-29 21:31:57.857577	\N	\N	\N	\N	f	\N	Wechsel von Objekt 14	2025-08-29 21:30:57.308251	\N	\N	\N	Unterhaltsreinigung	15.00
265	6	7	2025-09-04 06:00:00	2025-09-04 08:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B) - Grundreinigung	2025-09-04 12:01:53.276568	\N	\N	\N	Grundreinigung	15.00
266	6	13	2025-09-04 06:00:00	2025-09-04 07:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B) - Grundreinigung	2025-09-04 12:42:16.673647	\N	\N	\N	Grundreinigung	20.00
225	16	1	2025-08-30 16:08:53.427019	2025-08-31 07:25:13.254805	\N	\N	\N	\N	f	\N	\N	2025-08-30 16:08:53.428586	\N	\N	\N	Unterhaltsreinigung	15.00
226	6	1	2025-08-31 06:00:00	2025-08-31 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-08-31 07:32:07.609592	\N	\N	\N	Unterhaltsreinigung	15.00
227	6	5	2025-08-31 06:00:00	2025-08-31 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-08-31 08:11:07.877172	\N	\N	\N	Unterhaltsreinigung	15.00
228	6	9	2025-08-31 06:00:00	2025-08-31 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-08-31 08:11:14.521506	\N	\N	\N	Unterhaltsreinigung	15.00
229	6	13	2025-08-31 06:00:00	2025-08-31 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-08-31 08:11:20.811861	\N	\N	\N	Unterhaltsreinigung	15.00
230	10	6	2025-08-31 06:00:00	2025-08-31 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-08-31 08:15:00.461629	\N	\N	\N	Unterhaltsreinigung	15.00
231	17	1	2025-08-31 08:16:53.022386	2025-08-31 08:16:57.816633	\N	\N	\N	\N	f	\N	\N	2025-08-31 08:16:53.023237	\N	\N	\N	Unterhaltsreinigung	15.00
232	6	15	2025-08-31 06:00:00	2025-08-31 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-08-31 08:25:02.904474	\N	\N	\N	Unterhaltsreinigung	15.00
233	17	16	2025-08-31 08:25:50.703775	2025-08-31 08:26:26.312018	\N	\N	\N	\N	f	\N	\N	2025-08-31 08:25:50.704255	\N	\N	\N	Unterhaltsreinigung	15.00
234	6	6	2025-08-31 06:00:00	2025-08-31 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-08-31 10:15:00.874968	\N	\N	\N	Unterhaltsreinigung	15.00
235	9	11	2025-08-31 10:51:23.142984	2025-08-31 10:59:35.639551	\N	\N	\N	\N	f	\N	\N	2025-08-31 10:51:23.143919	\N	\N	\N	Unterhaltsreinigung	15.00
238	4	1	2025-08-31 12:00:18.618138	2025-08-31 14:03:18.618138	\N	\N	\N	\N	t	\N	Auto-Booking Kategorie A	2025-08-31 12:03:18.677368	\N	\N	\N	Unterhaltsreinigung	15.00
239	17	3	2025-08-31 14:44:08.467253	2025-08-31 15:10:30.259642	\N	\N	\N	\N	f	\N	\N	2025-08-31 14:44:08.468924	\N	\N	\N	Unterhaltsreinigung	15.00
240	17	3	2025-08-31 15:10:33.023358	2025-09-01 07:42:42.23809	\N	\N	\N	\N	f	\N	\N	2025-08-31 15:10:33.023856	\N	\N	\N	Unterhaltsreinigung	15.00
241	6	4	2025-09-01 06:00:00	2025-09-01 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-01 07:23:26.860101	\N	\N	\N	Unterhaltsreinigung	15.00
242	10	14	2025-09-01 06:00:00	2025-09-01 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-01 07:35:38.499094	\N	\N	\N	Unterhaltsreinigung	15.00
243	10	1	2025-09-01 06:00:00	2025-09-01 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-01 07:35:46.606377	\N	\N	\N	Unterhaltsreinigung	15.00
244	10	4	2025-09-01 06:00:00	2025-09-01 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-01 07:53:29.005854	\N	\N	\N	Unterhaltsreinigung	15.00
245	6	1	2025-09-01 06:00:00	2025-09-01 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-01 11:04:59.972872	\N	\N	\N	Unterhaltsreinigung	15.00
246	10	7	2025-09-02 06:00:00	2025-09-02 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-02 09:19:14.037677	\N	\N	\N	Unterhaltsreinigung	15.00
247	10	11	2025-09-02 06:00:00	2025-09-02 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-02 14:27:44.43058	\N	\N	\N	Unterhaltsreinigung	15.00
248	10	8	2025-09-02 06:00:00	2025-09-02 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-02 14:28:30.083668	\N	\N	\N	Unterhaltsreinigung	15.00
249	17	1	2025-09-02 14:31:01.856642	2025-09-02 14:31:03.842502	\N	\N	\N	\N	f	\N	\N	2025-09-02 14:31:01.857548	\N	\N	\N	Unterhaltsreinigung	15.00
250	17	11	2025-09-02 14:31:07.942365	2025-09-02 14:31:27.168582	\N	\N	\N	\N	f	\N	\N	2025-09-02 14:31:07.942804	\N	\N	\N	Unterhaltsreinigung	15.00
251	4	3	2025-09-02 15:00:01.712434	2025-09-02 20:00:01.712434	\N	\N	\N	\N	t	\N	Auto-Booking Kategorie A	2025-09-02 18:00:01.784664	\N	\N	\N	Unterhaltsreinigung	15.00
252	6	3	2025-09-02 06:00:00	2025-09-02 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-02 18:46:17.877487	\N	\N	\N	Unterhaltsreinigung	15.00
253	6	12	2025-09-02 06:00:00	2025-09-02 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-02 18:46:24.077935	\N	\N	\N	Unterhaltsreinigung	15.00
254	10	3	2025-09-02 06:00:00	2025-09-02 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-02 18:58:08.249272	\N	\N	\N	Unterhaltsreinigung	15.00
256	6	1	2025-09-02 06:00:00	2025-09-02 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-02 19:19:54.419679	\N	\N	\N	Unterhaltsreinigung	15.00
257	10	16	2025-09-02 06:00:00	2025-09-02 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-02 20:49:41.237676	\N	\N	\N	Unterhaltsreinigung	15.00
255	10	4	2025-09-02 19:17:29.892415	2025-09-03 09:24:25.393444	\N	\N	\N	\N	f	\N	\N	2025-09-02 19:17:29.893307	\N	\N	\N	Unterhaltsreinigung	15.00
236	9	1	2025-08-31 11:23:01.014725	2025-09-03 09:41:10.143556	\N	\N	\N	\N	f	\N	\N	2025-08-31 11:23:01.015203	\N	\N	\N	Unterhaltsreinigung	15.00
259	10	1	2025-09-03 06:00:00	2025-09-03 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-03 20:46:13.468433	\N	\N	\N	Unterhaltsreinigung	15.00
258	17	1	2025-09-03 20:30:53.185874	2025-09-04 06:15:55.649008	\N	\N	\N	\N	f	\N	\N	2025-09-03 20:30:53.187707	\N	\N	\N	Unterhaltsreinigung	15.00
260	6	4	2025-09-04 06:00:00	2025-09-04 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-04 06:54:27.499472	\N	\N	\N	Unterhaltsreinigung	15.00
261	6	1	2025-09-04 06:00:00	2025-09-04 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B)	2025-09-04 08:27:42.185392	\N	\N	\N	Unterhaltsreinigung	15.00
262	6	3	2025-09-04 06:00:00	2025-09-04 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B) - Fensterreinigung	2025-09-04 09:48:15.909577	\N	\N	\N	Fensterreinigung	15.00
263	6	5	2025-09-04 06:00:00	2025-09-04 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B) - Grundreinigung	2025-09-04 09:56:14.403712	\N	\N	\N	Grundreinigung	15.00
264	6	15	2025-09-04 06:00:00	2025-09-04 08:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B) - Fensterreinigung	2025-09-04 10:47:51.942008	\N	\N	\N	Fensterreinigung	15.00
267	17	16	2025-09-04 14:34:22.153682	2025-09-04 14:34:36.648721	\N	\N	\N	\N	f	\N	\N	2025-09-04 14:34:22.155473	\N	\N	\N	Unterhaltsreinigung	15.00
268	17	3	2025-09-06 07:43:17.022648	2025-09-06 07:43:20.519746	\N	\N	\N	\N	f	\N	\N	2025-09-06 07:43:17.024263	\N	\N	\N	Unterhaltsreinigung	15.00
269	10	1	2025-09-06 06:00:00	2025-09-06 10:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B) - Fensterreinigung	2025-09-06 07:43:40.277411	\N	\N	\N	Fensterreinigung	20.00
270	6	14	2025-09-07 06:00:00	2025-09-07 12:00:00	\N	\N	\N	\N	t	\N	War anwesend (Kategorie B) - Grundreinigung	2025-09-07 06:31:32.547046	\N	\N	\N	Grundreinigung	20.00
271	4	4	2025-09-07 11:00:01.975041	2025-09-07 13:00:01.975041	\N	\N	\N	\N	t	\N	Auto-Booking Kategorie A	2025-09-07 11:00:02.044288	\N	\N	\N	Unterhaltsreinigung	15.00
272	4	15	2025-09-07 13:30:01.381997	2025-09-07 17:30:01.381997	\N	\N	\N	\N	t	\N	Auto-Booking Kategorie A	2025-09-07 15:30:01.445236	\N	\N	\N	Unterhaltsreinigung	15.00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: seda24_user
--

COPY public.users (id, email, password_hash, role, is_active, created_at, category) FROM stdin;
35	eliane.dasilvatodaro@seda24.de	$2b$12$f9QeOgowoAVSBzExrulGD..HjulHDh.gifkVSxurawyTdkLhg5vCW	MITARBEITER	t	2025-08-20 10:42:05.330245	C
32	matej.stjepic@seda24.de	$2b$12$f9QeOgowoAVSBzExrulGD..HjulHDh.gifkVSxurawyTdkLhg5vCW	MITARBEITER	t	2025-08-20 10:42:04.465859	B
31	ljubica.stjepic@seda24.de	$2b$12$f9QeOgowoAVSBzExrulGD..HjulHDh.gifkVSxurawyTdkLhg5vCW	MITARBEITER	t	2025-08-20 10:42:04.179334	B
33	eldina.mustafic@seda24.de	$2b$12$f9QeOgowoAVSBzExrulGD..HjulHDh.gifkVSxurawyTdkLhg5vCW	MITARBEITER	t	2025-08-20 10:42:04.753891	C
34	jana.bojko@seda24.de	$2b$12$f9QeOgowoAVSBzExrulGD..HjulHDh.gifkVSxurawyTdkLhg5vCW	MITARBEITER	t	2025-08-20 10:42:05.043339	C
36	andreas.frosch@seda24.de	$2b$12$f9QeOgowoAVSBzExrulGD..HjulHDh.gifkVSxurawyTdkLhg5vCW	MITARBEITER	t	2025-08-20 10:42:05.621763	B
41	sonja.mutlak@seda24.de	$2b$12$f9QeOgowoAVSBzExrulGD..HjulHDh.gifkVSxurawyTdkLhg5vCW	MITARBEITER	t	2025-08-25 09:42:31.390903	A
40	dsertic@sertic.de	$2b$12$f9QeOgowoAVSBzExrulGD..HjulHDh.gifkVSxurawyTdkLhg5vCW	MITARBEITER	t	2025-08-22 18:04:39.965063	A
30	ruzica.sertic@seda.de	$2b$12$f9QeOgowoAVSBzExrulGD..HjulHDh.gifkVSxurawyTdkLhg5vCW	MITARBEITER	t	2025-08-20 10:42:03.875689	A
42	test@seda24.de	temp123	MITARBEITER	t	2025-09-07 16:14:29.398871	C
48	dsertic@seda24.de	temp123	MITARBEITER	t	2025-09-07 16:58:33.528292	C
51	test@gmx.de	temp123	MITARBEITER	t	2025-09-07 17:04:38.384231	C
52	neu@gmx.de	temp123	MITARBEITER	t	2025-09-07 17:05:43.891821	C
1	admin@seda24.de	$2b$12$7hNPFfmD44LfESMWdifWp.g0AZIyO6PUlI7sGvsmbF3fNFc.bSDEa	ADMIN	t	2025-08-15 20:59:40.868657	A
\.


--
-- Data for Name: warnings; Type: TABLE DATA; Schema: public; Owner: seda24_user
--

COPY public.warnings (id, employee_id, warning_type, message, is_resolved, created_at, resolved_at) FROM stdin;
\.


--
-- Name: break_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seda24_user
--

SELECT pg_catalog.setval('public.break_entries_id_seq', 3, true);


--
-- Name: correction_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seda24_user
--

SELECT pg_catalog.setval('public.correction_requests_id_seq', 1, true);


--
-- Name: customer_hours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_hours_id_seq', 21, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seda24_user
--

SELECT pg_catalog.setval('public.customers_id_seq', 14, true);


--
-- Name: employee_object_hours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seda24_user
--

SELECT pg_catalog.setval('public.employee_object_hours_id_seq', 1, false);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seda24_user
--

SELECT pg_catalog.setval('public.employees_id_seq', 23, true);


--
-- Name: hourly_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hourly_rates_id_seq', 1, false);


--
-- Name: objects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seda24_user
--

SELECT pg_catalog.setval('public.objects_id_seq', 18, true);


--
-- Name: quick_bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seda24_user
--

SELECT pg_catalog.setval('public.quick_bookings_id_seq', 1, false);


--
-- Name: replacement_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.replacement_rules_id_seq', 1, false);


--
-- Name: schedule_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_history_id_seq', 1, false);


--
-- Name: schedule_template_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_template_items_id_seq', 1, false);


--
-- Name: schedule_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_templates_id_seq', 1, false);


--
-- Name: schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedules_id_seq', 619, true);


--
-- Name: special_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.special_rules_id_seq', 4, true);


--
-- Name: time_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seda24_user
--

SELECT pg_catalog.setval('public.time_entries_id_seq', 272, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seda24_user
--

SELECT pg_catalog.setval('public.users_id_seq', 52, true);


--
-- Name: warnings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seda24_user
--

SELECT pg_catalog.setval('public.warnings_id_seq', 6, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: break_entries break_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.break_entries
    ADD CONSTRAINT break_entries_pkey PRIMARY KEY (id);


--
-- Name: correction_requests correction_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.correction_requests
    ADD CONSTRAINT correction_requests_pkey PRIMARY KEY (id);


--
-- Name: customer_hours customer_hours_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_hours
    ADD CONSTRAINT customer_hours_customer_id_key UNIQUE (customer_id);


--
-- Name: customer_hours customer_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_hours
    ADD CONSTRAINT customer_hours_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: employee_object_hours employee_object_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.employee_object_hours
    ADD CONSTRAINT employee_object_hours_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: employees employees_user_id_key; Type: CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_user_id_key UNIQUE (user_id);


--
-- Name: hourly_rates hourly_rates_employee_id_rate_type_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hourly_rates
    ADD CONSTRAINT hourly_rates_employee_id_rate_type_key UNIQUE (employee_id, rate_type);


--
-- Name: hourly_rates hourly_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hourly_rates
    ADD CONSTRAINT hourly_rates_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: quick_bookings quick_bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.quick_bookings
    ADD CONSTRAINT quick_bookings_pkey PRIMARY KEY (id);


--
-- Name: replacement_rules replacement_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.replacement_rules
    ADD CONSTRAINT replacement_rules_pkey PRIMARY KEY (id);


--
-- Name: schedule_history schedule_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_history
    ADD CONSTRAINT schedule_history_pkey PRIMARY KEY (id);


--
-- Name: schedule_template_items schedule_template_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_template_items
    ADD CONSTRAINT schedule_template_items_pkey PRIMARY KEY (id);


--
-- Name: schedule_templates schedule_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_templates
    ADD CONSTRAINT schedule_templates_pkey PRIMARY KEY (id);


--
-- Name: schedules schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_pkey PRIMARY KEY (id);


--
-- Name: special_rules special_rules_employee_id_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.special_rules
    ADD CONSTRAINT special_rules_employee_id_customer_id_key UNIQUE (employee_id, customer_id);


--
-- Name: special_rules special_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.special_rules
    ADD CONSTRAINT special_rules_pkey PRIMARY KEY (id);


--
-- Name: time_entries time_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warnings warnings_pkey; Type: CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.warnings
    ADD CONSTRAINT warnings_pkey PRIMARY KEY (id);


--
-- Name: idx_schedules_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_schedules_employee ON public.schedules USING btree (employee_id);


--
-- Name: idx_schedules_object; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_schedules_object ON public.schedules USING btree (object_id);


--
-- Name: idx_schedules_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_schedules_status ON public.schedules USING btree (status);


--
-- Name: idx_schedules_weekday; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_schedules_weekday ON public.schedules USING btree (weekday);


--
-- Name: ix_break_entries_id; Type: INDEX; Schema: public; Owner: seda24_user
--

CREATE INDEX ix_break_entries_id ON public.break_entries USING btree (id);


--
-- Name: ix_correction_requests_id; Type: INDEX; Schema: public; Owner: seda24_user
--

CREATE INDEX ix_correction_requests_id ON public.correction_requests USING btree (id);


--
-- Name: ix_customers_id; Type: INDEX; Schema: public; Owner: seda24_user
--

CREATE INDEX ix_customers_id ON public.customers USING btree (id);


--
-- Name: ix_customers_name; Type: INDEX; Schema: public; Owner: seda24_user
--

CREATE INDEX ix_customers_name ON public.customers USING btree (name);


--
-- Name: ix_employees_id; Type: INDEX; Schema: public; Owner: seda24_user
--

CREATE INDEX ix_employees_id ON public.employees USING btree (id);


--
-- Name: ix_employees_personal_nr; Type: INDEX; Schema: public; Owner: seda24_user
--

CREATE UNIQUE INDEX ix_employees_personal_nr ON public.employees USING btree (personal_nr);


--
-- Name: ix_objects_id; Type: INDEX; Schema: public; Owner: seda24_user
--

CREATE INDEX ix_objects_id ON public.objects USING btree (id);


--
-- Name: ix_objects_name; Type: INDEX; Schema: public; Owner: seda24_user
--

CREATE INDEX ix_objects_name ON public.objects USING btree (name);


--
-- Name: ix_quick_bookings_id; Type: INDEX; Schema: public; Owner: seda24_user
--

CREATE INDEX ix_quick_bookings_id ON public.quick_bookings USING btree (id);


--
-- Name: ix_time_entries_id; Type: INDEX; Schema: public; Owner: seda24_user
--

CREATE INDEX ix_time_entries_id ON public.time_entries USING btree (id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: seda24_user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: seda24_user
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_warnings_id; Type: INDEX; Schema: public; Owner: seda24_user
--

CREATE INDEX ix_warnings_id ON public.warnings USING btree (id);


--
-- Name: schedules update_schedules_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_schedules_updated_at BEFORE UPDATE ON public.schedules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: break_entries break_entries_time_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.break_entries
    ADD CONSTRAINT break_entries_time_entry_id_fkey FOREIGN KEY (time_entry_id) REFERENCES public.time_entries(id);


--
-- Name: correction_requests correction_requests_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.correction_requests
    ADD CONSTRAINT correction_requests_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: correction_requests correction_requests_processed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.correction_requests
    ADD CONSTRAINT correction_requests_processed_by_fkey FOREIGN KEY (processed_by) REFERENCES public.users(id);


--
-- Name: correction_requests correction_requests_time_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.correction_requests
    ADD CONSTRAINT correction_requests_time_entry_id_fkey FOREIGN KEY (time_entry_id) REFERENCES public.time_entries(id);


--
-- Name: customer_hours customer_hours_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_hours
    ADD CONSTRAINT customer_hours_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: employee_object_hours employee_object_hours_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.employee_object_hours
    ADD CONSTRAINT employee_object_hours_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_object_hours employee_object_hours_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.employee_object_hours
    ADD CONSTRAINT employee_object_hours_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.objects(id);


--
-- Name: employees employees_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: hourly_rates hourly_rates_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hourly_rates
    ADD CONSTRAINT hourly_rates_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: objects objects_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.objects
    ADD CONSTRAINT objects_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: quick_bookings quick_bookings_booked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.quick_bookings
    ADD CONSTRAINT quick_bookings_booked_by_fkey FOREIGN KEY (booked_by) REFERENCES public.users(id);


--
-- Name: quick_bookings quick_bookings_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.quick_bookings
    ADD CONSTRAINT quick_bookings_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: quick_bookings quick_bookings_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.quick_bookings
    ADD CONSTRAINT quick_bookings_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.objects(id);


--
-- Name: replacement_rules replacement_rules_primary_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.replacement_rules
    ADD CONSTRAINT replacement_rules_primary_employee_id_fkey FOREIGN KEY (primary_employee_id) REFERENCES public.employees(id);


--
-- Name: replacement_rules replacement_rules_replacement_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.replacement_rules
    ADD CONSTRAINT replacement_rules_replacement_employee_id_fkey FOREIGN KEY (replacement_employee_id) REFERENCES public.employees(id);


--
-- Name: schedule_history schedule_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_history
    ADD CONSTRAINT schedule_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);


--
-- Name: schedule_history schedule_history_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_history
    ADD CONSTRAINT schedule_history_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.schedules(id);


--
-- Name: schedule_template_items schedule_template_items_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_template_items
    ADD CONSTRAINT schedule_template_items_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: schedule_template_items schedule_template_items_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_template_items
    ADD CONSTRAINT schedule_template_items_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.objects(id);


--
-- Name: schedule_template_items schedule_template_items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_template_items
    ADD CONSTRAINT schedule_template_items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.schedule_templates(id) ON DELETE CASCADE;


--
-- Name: schedule_templates schedule_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_templates
    ADD CONSTRAINT schedule_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: schedules schedules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: schedules schedules_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: schedules schedules_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.objects(id);


--
-- Name: schedules schedules_replacement_for_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_replacement_for_fkey FOREIGN KEY (replacement_for) REFERENCES public.employees(id);


--
-- Name: special_rules special_rules_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.special_rules
    ADD CONSTRAINT special_rules_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: special_rules special_rules_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.special_rules
    ADD CONSTRAINT special_rules_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: time_entries time_entries_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: time_entries time_entries_object_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_object_id_fkey FOREIGN KEY (object_id) REFERENCES public.objects(id);


--
-- Name: warnings warnings_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seda24_user
--

ALTER TABLE ONLY public.warnings
    ADD CONSTRAINT warnings_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO seda24_user;


--
-- Name: TABLE schedules; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.schedules TO seda24_user;


--
-- Name: SEQUENCE schedules_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.schedules_id_seq TO seda24_user;


--
-- PostgreSQL database dump complete
--

\unrestrict 7x5ezjXa3ucLesaf3Ndbr2CE3MTPrNU8EtM9CLYUaRyWhwp8vQXwmiI3PbwqrHP

