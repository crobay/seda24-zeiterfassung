import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { LogOut, Play, Square, Pause, PlayCircle, MapPin, AlertCircle, CheckCircle, Users, User, Building, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isWorking, setIsWorking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [pauseId, setPauseId] = useState(null);
  const [workStartTime, setWorkStartTime] = useState(null);
  const [pauseStartTime, setPauseStartTime] = useState(null);
  const [totalPauseTime, setTotalPauseTime] = useState(0);
  const [todayHours, setTodayHours] = useState(0);
  const [weekHours, setWeekHours] = useState(0);
  const [monthHours, setMonthHours] = useState(0);
  const [totalHours, setTotalHours] = useState(2856); // Beispiel Tacho-Stand
  const [selectedObject, setSelectedObject] = useState(1);
  const [employeeData, setEmployeeData] = useState(null);
  const [showQuickBooking, setShowQuickBooking] = useState(false);
  const [workingWithColleague, setWorkingWithColleague] = useState(false);
  const [selectedColleague, setSelectedColleague] = useState('');
  const [userLocation, setUserLocation] = useState(null);
  const [locationError, setLocationError] = useState(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  const navigate = useNavigate();
  const API_URL = 'https://192.168.178.87:8001/api/v1';
  const token = localStorage.getItem('token');

  // Objekt-Koordinaten
  const objectLocations = {
    1: { name: 'SEDA24 Zentrale', lat: 48.794968, lng: 8.310615 },
    3: { name: 'Lidl Muggensturmer Str', lat: 48.8888214774413, lng: 8.26481250682591 },
    4: { name: 'Lidl Wochenende', lat: 48.8888214774413, lng: 8.26481250682591 },
    5: { name: 'Enfido Sonnenschein', lat: 48.9090646883034, lng: 8.26101850482367 },
    6: { name: 'Metalicone Muggensturm', lat: 48.8797133935092, lng: 8.28035636486564 },
    7: { name: 'JU_RA Baden-Baden', lat: 48.7612319749530, lng: 8.25051555347136 },
    8: { name: 'Huber Iffezheim', lat: 48.8167103890530, lng: 8.15985572143728 },
    9: { name: 'BAD-Treppen', lat: 48.7576771385761, lng: 8.24505946642259 },
    11: { name: 'Leible Rheinmünster', lat: 48.7498572046747, lng: 8.03728945082595 },
    12: { name: 'Zinsfabrik Baden-Baden', lat: 48.7664297331785, lng: 8.23475597645378 },
    13: { name: 'Polytec Rastatt', lat: 48.8657781551626, lng: 8.22110284976376 },
    14: { name: 'Steuerberater Baden-Baden', lat: 48.7611535126502, lng: 8.24928112428465 },
    15: { name: 'Geiger Malsch', lat: 48.8894361838853, lng: 8.31018689424884 },
    16: { name: 'Rytec Baden-Baden', lat: 48.7783217330924, lng: 8.20291705679789 }
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const fetchEmployeeData = async () => {
    try {
      const response = await axios.get(`${API_URL}/employees/me`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setEmployeeData(response.data);
      // Tacho-Stand: Start-Stunden + gearbeitete Stunden
      setTotalHours((response.data.start_hours || 0) + (response.data.total_worked || 0));
      if (response.data.tracking_mode === 'B') {
        setShowQuickBooking(true);
      }
    } catch (error) {
      console.error('Fehler beim Laden der Mitarbeiterdaten:', error);
    }
  };

  useEffect(() => {
    checkStatus();
    fetchTodayHours();
    fetchWeekHours();
    fetchMonthHours();
    fetchEmployeeData();
  }, []);

  const getCurrentLocation = () => {
    return new Promise((resolve, reject) => {
      setIsLoadingLocation(true);
      setLocationError(null);

      if (!navigator.geolocation) {
        setLocationError('GPS wird nicht unterstützt');
        setIsLoadingLocation(false);
        reject('Geolocation not supported');
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const location = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            accuracy: position.coords.accuracy
          };
          setUserLocation(location);
          setIsLoadingLocation(false);
          resolve(location);
        },
        (error) => {
          setLocationError('GPS nicht verfügbar');
          setIsLoadingLocation(false);
          reject(error);
        },
        { enableHighAccuracy: false, timeout: 30000, maximumAge: 10000 }
      );
    });
  };

  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371e3;
    const φ1 = lat1 * Math.PI/180;
    const φ2 = lat2 * Math.PI/180;
    const Δφ = (lat2-lat1) * Math.PI/180;
    const Δλ = (lon2-lon1) * Math.PI/180;
    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const validateLocation = async (objectId) => {
    try {
      const location = await getCurrentLocation();
      const object = objectLocations[parseInt(objectId)];
      if (!object) return true;

      const distance = calculateDistance(
        location.lat, location.lng,
        object.lat, object.lng
      );

      if (distance > 100) {
        setLocationError(`Achtung: ${Math.round(distance)}m vom ${object.name} entfernt`);
        setTimeout(() => setLocationError(null), 5000);
      }
      return true;
    } catch (error) {
      return true; // Trotzdem erlauben
    }
  };

  const checkStatus = async () => {
    try {
      const response = await axios.get(`${API_URL}/time-entries/current`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      if (response.data.is_working) {
        setIsWorking(true);
        const backendTime = new Date(response.data.check_in);
        const correctedTime = new Date(backendTime.getTime() + 2 * 60 * 60 * 1000);
        setWorkStartTime(correctedTime);
      } else {
        setIsWorking(false);
        setWorkStartTime(null);
      }
    } catch (error) {
      console.error('Status-Fehler:', error);
    }
  };

  const fetchTodayHours = async () => {
    try {
      const response = await axios.get(`${API_URL}/reports/my/today`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setTodayHours(response.data.total_hours);
    } catch (error) {
      console.error('Fehler:', error);
    }
  };

  const fetchWeekHours = async () => {
    try {
      const response = await axios.get(`${API_URL}/reports/my/week`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setWeekHours(response.data.total_hours);
    } catch (error) {
      console.error('Fehler:', error);
    }
  };

  const fetchMonthHours = async () => {
    try {
      const response = await axios.get(`${API_URL}/reports/my/month`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMonthHours(response.data.total_hours);
    } catch (error) {
      console.error('Fehler:', error);
    }
  };

  const handleQuickBooking = async () => {
    try {
      const dailyHours = employeeData?.daily_hours || 8;
      await axios.post(
        `${API_URL}/time-entries/quick-booking`,
        {
          object_id: parseInt(selectedObject),
          hours: dailyHours,
          notes: "War da - Sollstunden gebucht"
        },
        { headers: { Authorization: `Bearer ${token}` }}
      );
      alert(`${dailyHours} Stunden gebucht!`);
      fetchTodayHours();
      fetchWeekHours();
      fetchMonthHours();
    } catch (error) {
      alert("Fehler beim Buchen");
    }
  };

  const handleCheckIn = async () => {
    setLocationError(null);
    await validateLocation(selectedObject);

    try {
      const notes = workingWithColleague 
        ? `Arbeitsbeginn (zu zweit mit ${selectedColleague})`
        : "Arbeitsbeginn";

      await axios.post(
        `${API_URL}/time-entries/check-in`,
        {
          object_id: parseInt(selectedObject),
          notes: notes
        },
        { headers: { Authorization: `Bearer ${token}` }}
      );

      setIsWorking(true);
      setWorkStartTime(new Date());
      setTotalPauseTime(0);
      fetchTodayHours();
    } catch (error) {
      alert('Fehler beim Einstempeln');
    }
  };

  const handleCheckOut = async () => {
    try {
      await axios.post(
        `${API_URL}/time-entries/check-out`,
        {},
        { headers: { Authorization: `Bearer ${token}` }}
      );
      setIsWorking(false);
      setWorkStartTime(null);
      setTotalPauseTime(0);
      setWorkingWithColleague(false);
      setSelectedColleague('');
      fetchTodayHours();
      fetchWeekHours();
      fetchMonthHours();
      // Tacho erhöhen
      setTotalHours(prev => prev + (todayHours || 0));
    } catch (error) {
      alert('Fehler beim Ausstempeln');
    }
  };

  const calculateWorkTime = () => {
    if (!workStartTime) return '00:00:00';
    let totalSeconds = (currentTime - workStartTime) / 1000;
    totalSeconds -= totalPauseTime;
    
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = Math.floor(totalSeconds % 60);
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  const formatHours = (hours) => {
    if (hours === 0) return "0 Std";
    const h = Math.floor(hours);
    const m = Math.round((hours % 1) * 60);
    
    if (h === 0) return `${m} Min`;
    if (m === 0) return `${h} Std`;
    return `${h} Std ${m} Min`;
  };

  const formatTotalHours = (hours) => {
    return Math.floor(hours).toLocaleString('de-DE') + ' Std';
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userRole');
    navigate('/login');
  };

  return (
    <div className="min-h-screen" style={{background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'}}>
      <div className="max-w-2xl mx-auto p-4">
        
        {/* HEADER */}
        <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                {/* LOGO PLATZHALTER */}
<img 
  src="/seda24-logo.png" 
  alt="SEDA24" 
  style={{
    width: '50px',
    height: '50px',
    objectFit: 'contain'
  }}
/>
                <div>
                  <div style={{fontSize: '24px', fontWeight: 'bold', color: '#1e3a5f'}}>
                    SEDA24
                  </div>
                  <div style={{fontSize: '14px', color: '#2c5f7c'}}>
                    Zeiterfassung
                  </div>
                </div>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="px-6 py-2 rounded-lg text-white transition-all hover:scale-105"
              style={{backgroundColor: '#ef4444'}}
            >
              <LogOut size={20} className="inline mr-2" />
              Logout
            </button>
          </div>
        </div>

        {/* MAIN CARD */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          
          {/* UHRZEIT */}
          <div className="text-center mb-6">
            <div style={{fontSize: '60px', fontWeight: 'bold', color: '#1e3a5f'}}>
              {currentTime.toLocaleTimeString('de-DE')}
            </div>
            <div style={{fontSize: '18px', color: '#666'}}>
              {currentTime.toLocaleDateString('de-DE', {
                weekday: 'long',
                day: 'numeric',
                month: 'long',
                year: 'numeric'
              })}
            </div>
          </div>

          {/* MITARBEITER INFO BOX */}
          {employeeData && (
            <div style={{
              background: 'linear-gradient(135deg, #f5a623 0%, #f7b733 100%)',
              borderRadius: '12px',
              padding: '16px',
              marginBottom: '24px',
              color: 'white'
            }}>
              <div style={{fontSize: '14px', opacity: 0.9}}>
                <User size={16} className="inline mr-2" />
                Angemeldet als:
              </div>
              <div style={{fontSize: '18px', fontWeight: 'bold', marginTop: '4px'}}>
                {employeeData.first_name} {employeeData.last_name} ({employeeData.personal_nr})
              </div>
              {isWorking && (
                <div style={{fontSize: '14px', marginTop: '8px', opacity: 0.9}}>
                  <Building size={14} className="inline mr-2" />
                  {objectLocations[selectedObject]?.name} | Soll: {employeeData.daily_hours || 8}h
                  {workingWithColleague && selectedColleague && (
                    <span> | Mit: {selectedColleague}</span>
                  )}
                </div>
              )}
            </div>
          )}

          {/* GPS STATUS */}
          {locationError && (
            <div className="mb-4 p-3 rounded-lg" style={{
              background: '#fff3cd',
              border: '1px solid #ffc107',
              color: '#856404'
            }}>
              <AlertCircle size={16} className="inline mr-2" />
              {locationError}
            </div>
          )}

          {/* ARBEITSZEIT ANZEIGE */}
          {isWorking && (
            <div style={{
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              borderRadius: '16px',
              padding: '24px',
              marginBottom: '24px',
              color: 'white',
              textAlign: 'center'
            }}>
              <div style={{fontSize: '20px', marginBottom: '8px'}}>
                ARBEITSZEIT LÄUFT
              </div>
              <div style={{fontSize: '48px', fontWeight: 'bold', fontFamily: 'monospace'}}>
                {calculateWorkTime()}
              </div>
            </div>
          )}

          {/* OBJEKT AUSWAHL */}
          {!isWorking && (
            <>
              <div className="mb-4">
                <label style={{fontSize: '14px', color: '#666', display: 'block', marginBottom: '8px'}}>
                  Objekt wählen:
                </label>
                <select
                  value={selectedObject}
                  onChange={(e) => setSelectedObject(parseInt(e.target.value))}
                  style={{
                    width: '100%',
                    padding: '12px',
                    fontSize: '16px',
                    border: '2px solid #e0e0e0',
                    borderRadius: '8px',
                    outline: 'none'
                  }}
                >
                  <option value="1">SEDA24 Zentrale</option>
                  <option value="3">Lidl Muggensturmer Str</option>
                  <option value="4">Lidl Wochenende</option>
                  <option value="5">Enfido Sonnenschein</option>
                  <option value="6">Metalicone Muggensturm</option>
                  <option value="7">JU_RA Baden-Baden</option>
                  <option value="8">Huber Iffezheim</option>
                  <option value="9">BAD-Treppen</option>
                  <option value="11">Leible Rheinmünster</option>
                  <option value="12">Zinsfabrik Baden-Baden</option>
                  <option value="13">Polytec Rastatt</option>
                  <option value="14">Steuerberater Baden-Baden</option>
                  <option value="15">Geiger Malsch</option>
                  <option value="16">Rytec Baden-Baden</option>
                </select>
              </div>

              {/* ZU ZWEIT OPTION */}
              <div style={{
                background: '#f8f9fa',
                borderRadius: '8px',
                padding: '16px',
                marginBottom: '24px'
              }}>
                <label style={{display: 'flex', alignItems: 'center', cursor: 'pointer'}}>
                  <input
                    type="checkbox"
                    checked={workingWithColleague}
                    onChange={(e) => setWorkingWithColleague(e.target.checked)}
                    style={{marginRight: '12px', width: '20px', height: '20px'}}
                  />
                  <span style={{fontSize: '16px', color: '#333'}}>
                    <Users size={20} className="inline mr-2" />
                    Zu zweit arbeiten
                  </span>
                </label>
                {workingWithColleague && (
                  <select
                    value={selectedColleague}
                    onChange={(e) => setSelectedColleague(e.target.value)}
                    style={{
                      width: '100%',
                      marginTop: '12px',
                      padding: '10px',
                      fontSize: '16px',
                      border: '1px solid #e0e0e0',
                      borderRadius: '6px'
                    }}
                  >
                    <option value="">Kollegen wählen...</option>
                    <option value="Ruza (D002)">Ruza Sertic</option>
                    <option value="Ljubica (D003)">Ljubica Stjepic</option>
                    <option value="Matej (D004)">Matej Stjepic</option>
                    <option value="Eldina (D010)">Eldina Mustafic</option>
                    <option value="Jana (D013)">Jana Bojko</option>
                    <option value="Elia (D031)">Eliane DaSilvaTodaro</option>
                    <option value="Andy (D032)">Andreas Frosch</option>
                  </select>
                )}
              </div>
            </>
          )}

          {/* ACTION BUTTONS */}
          {!isWorking ? (
            <>
              {showQuickBooking && (
                <button
                  onClick={handleQuickBooking}
                  style={{
                    width: '100%',
                    padding: '24px',
                    background: '#f5a623',
                    color: 'white',
                    fontSize: '20px',
                    fontWeight: 'bold',
                    borderRadius: '12px',
                    border: 'none',
                    marginBottom: '12px',
                    cursor: 'pointer',
                    transition: 'transform 0.2s',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '12px'
                  }}
                  onMouseOver={(e) => e.currentTarget.style.transform = 'scale(1.02)'}
                  onMouseOut={(e) => e.currentTarget.style.transform = 'scale(1)'}
                >
                  <CheckCircle size={28} />
                  WAR DA - SOLLSTUNDEN BUCHEN
                </button>
              )}
              
              <button
                onClick={handleCheckIn}
                disabled={isLoadingLocation}
                style={{
                  width: '100%',
                  padding: '32px',
                  background: 'linear-gradient(135deg, #1e3a5f 0%, #2c5f7c 100%)',
                  color: 'white',
                  fontSize: '24px',
                  fontWeight: 'bold',
                  borderRadius: '16px',
                  border: 'none',
                  cursor: 'pointer',
                  transition: 'transform 0.2s',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '12px'
                }}
                onMouseOver={(e) => e.currentTarget.style.transform = 'scale(1.02)'}
                onMouseOut={(e) => e.currentTarget.style.transform = 'scale(1)'}
              >
                <Play size={32} />
                ARBEIT BEGINNEN
              </button>
            </>
          ) : (
            <button
              onClick={handleCheckOut}
              style={{
                width: '100%',
                padding: '32px',
                background: 'linear-gradient(135deg, #dc2626 0%, #ef4444 100%)',
                color: 'white',
                fontSize: '24px',
                fontWeight: 'bold',
                borderRadius: '16px',
                border: 'none',
                cursor: 'pointer',
                transition: 'transform 0.2s',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '12px'
              }}
              onMouseOver={(e) => e.currentTarget.style.transform = 'scale(1.02)'}
              onMouseOut={(e) => e.currentTarget.style.transform = 'scale(1)'}
            >
              <Square size={32} />
              ARBEIT BEENDEN
            </button>
          )}

          {/* STATISTIK */}
          <div style={{marginTop: '32px', paddingTop: '24px', borderTop: '2px solid #e0e0e0'}}>
            <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px'}}>
              <div style={{
                background: '#f8f9fa',
                padding: '16px',
                borderRadius: '8px',
                textAlign: 'center'
              }}>
                <div style={{fontSize: '12px', color: '#666', marginBottom: '4px'}}>
                  Heute
                </div>
                <div style={{fontSize: '24px', fontWeight: 'bold', color: '#1e3a5f'}}>
                  {formatHours(todayHours)}
                </div>
              </div>
              
              <div style={{
                background: '#f8f9fa',
                padding: '16px',
                borderRadius: '8px',
                textAlign: 'center'
              }}>
                <div style={{fontSize: '12px', color: '#666', marginBottom: '4px'}}>
                  Diese Woche
                </div>
                <div style={{fontSize: '24px', fontWeight: 'bold', color: '#1e3a5f'}}>
                  {formatHours(weekHours)}
                </div>
              </div>
              
              <div style={{
                background: '#f8f9fa',
                padding: '16px',
                borderRadius: '8px',
                textAlign: 'center'
              }}>
                <div style={{fontSize: '12px', color: '#666', marginBottom: '4px'}}>
                  Dieser Monat
                </div>
                <div style={{fontSize: '24px', fontWeight: 'bold', color: '#1e3a5f'}}>
                  {formatHours(monthHours)}
                </div>
              </div>
              
              <div style={{
                background: 'linear-gradient(135deg, #f5a623 0%, #f7b733 100%)',
                padding: '16px',
                borderRadius: '8px',
                textAlign: 'center'
              }}>
                <div style={{fontSize: '12px', color: '#fff', marginBottom: '4px'}}>
                  <Clock size={14} className="inline mr-1" />
                  Seit Beginn
                </div>
                <div style={{fontSize: '24px', fontWeight: 'bold', color: '#fff'}}>
                  {formatTotalHours(totalHours)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;